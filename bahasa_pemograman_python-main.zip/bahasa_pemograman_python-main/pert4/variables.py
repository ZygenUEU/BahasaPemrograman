# python variables
# x adalah int
#x = 5
# y adalah string
#y = "John"
#print(x)
#print(y)

# multiple values
#x, y, z = "ani", "budi", "toni"
#print(x)
#print(y)
#print(z)

#print (x,y,z)

# Global Variables
#a = "budi"

#def func():
#    a = "ani"
#    print ("selamat belajar " + a)

#func()

#print ("selamat belajar " + a)


# # sample

#def tambah():
#    a = 5
#    b = 3
#    c = a + b
#    print (c)
#tambah()


# ini menampilkan nim dan nama

#def input():
#    nama = "ani"
#    nim = 123456
#    print (nim, nama)

#input()

def header():
    print("=================")
    print("PROGRAM QUIZ")
    print("====================")

header()

def a():
    #nim=input("masukkan nim : ")
    nama=input("masukkan nama : ")
    nim =int(input("masukkan nim : "))

a()

# python 3 cant use name input/other function from module library
