def hitung_luas ():
  alas = float(input('Masukkan alas: '))
  tinggi = float(input('Masukkan tinggi: '))
  print('Luas =', 0.5 * alas * tinggi)

# kita bisa panggil berkali-kali
hitung_luas()
# panggil lagi
# hitung_luas()