from pymongo import MongoClient

client = MongoClient("mongodb://admin:p455w0rd@172.30.247.244:27017/mydb?authSource=admin")
#db = MongoClient("mongodb://admin:p455w0rd@172.30.247.244:27017/mydb").get_database()
#print(db.name)
# mydb = con["mydatabase"]

# dblist = con.list_database_names()
# if "mydatabase" in dblist:
#   print("The database exists.")
# db = client['mydb']
# print("Database created........")

# #Verification
# print("List of databases after creating new one")
print(client.list_database_names())

# mycol = mydb["customers"]
# collist = mydb.list_collection_names()
# if "customers" in collist:
#   print("The collection exists.")

#print(mydb.list_collection_names())