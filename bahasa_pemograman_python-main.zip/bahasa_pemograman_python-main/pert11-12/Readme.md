1. pip install pymongo
