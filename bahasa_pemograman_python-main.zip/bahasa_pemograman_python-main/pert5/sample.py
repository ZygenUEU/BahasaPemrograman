# definisi function

#header
def kepala():
    print ("NAMASAYA J")
    print ("NIMSAYA 1")
    print ("----------")
#body
def penjumlahan():
    print("masukkan angka 1 : ")
    print("masukkan angka 2 : ")



#footer
def kaki():
    print ("Terima Kasih")

while True:
    kepala()