print ("hello world!")

a = 3
b = 2

print (a+b)


nama = "jefry sunupurwa asri"

print (nama)