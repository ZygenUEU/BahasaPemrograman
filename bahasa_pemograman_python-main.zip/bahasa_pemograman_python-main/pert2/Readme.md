# Introduction to Python

## Hello World in Python
```python
print ("Hello World!")
```

## Integer in Python
```python
a = 3
b = 2
print (a+b)
```

## String in Python
```python
nama = "jefry sunupurwa asri"

print (nama)
```