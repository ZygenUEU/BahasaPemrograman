# Pertemuan 6 ARRAY

variable_name = array(typecode,[elements])

variable_name = nama variabelnya
typecode = spesifikasi element yang mau di simpan
elements = data yang ingin disimpan dalam array

TYPECODE    TYPE
'b'	        int
'B'		    int
'u'	        character
'h'		    int
'H'		    int
'i'		    int
'I'		    int
'l'		    int
'L'		    int
'q'		    int
'Q'		    int
'f'	        float	
'd'	        float	