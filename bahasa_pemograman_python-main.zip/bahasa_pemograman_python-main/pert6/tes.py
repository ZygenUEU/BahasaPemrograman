print ("DAFTAR BARANG")
print ("1. TEH")
print ("2. KOPI")

a = int(input("masukkan pilihan : "))
print (a)