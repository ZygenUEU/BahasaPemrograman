import array as arr 

numbers = arr.array('i',[10,20,30])

print(numbers)

import array as arr 

numbers = arr.array('i',[10,20,30])

for number in numbers:
    print(number)


import array as arr  

values = arr.array('i',[10,20,30])

#prints each individual value in the array
for value in range(len(values)):
    print(values[value])